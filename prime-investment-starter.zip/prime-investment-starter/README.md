# Prime Investment — starter project

Luxury navy/gold responsive Next.js + Supabase starter for `primetech4u.online`.

## Important scope and safeguards
This is a development prototype. It supports email sign-up/login and a protected demo dashboard. It does **not** accept deposits, process withdrawals, make loans, execute trades, calculate guaranteed returns, or promise profits. The plan prices are display-only entry-tier examples. Do not turn on real-money functionality until the operating business, product disclosures, custody/segregation, payment flows, risk controls, and all required Nigerian authorisations have been independently reviewed.

## 1. Install
Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env.local
```

## 2. Configure Supabase
1. Open your Supabase project.
2. Go to Project Settings → API.
3. Copy the Project URL and `anon` / publishable key into `.env.local`.
4. In Authentication → URL Configuration, set Site URL to your eventual production URL and add `http://localhost:3000/**` to Redirect URLs for local development.
5. Open SQL Editor and run `supabase/schema.sql`.

Never put a Supabase `service_role` key in browser code or in any `NEXT_PUBLIC_` variable.

## 3. Run locally
```bash
npm run dev
```
Open http://localhost:3000. Test sign-up and email verification. Configure SMTP in Supabase before production so verification messages are delivered reliably.

## 4. Deploy to Vercel
1. Push this folder to a private GitHub repository.
2. In Vercel, choose Add New → Project and import the repository.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` under Project Settings → Environment Variables.
4. Deploy.
5. In Vercel project Settings → Domains, add `primetech4u.online` and `www.primetech4u.online` if desired.
6. Vercel will show the exact DNS records required. Add only those records in GoDaddy DNS; do not guess values or delete unrelated email records.
7. Update Supabase Auth Site URL and Redirect URLs to the production domain.

## 5. Before production
- Add an audited administrator role system using server-side authorization; do not make a user an admin by editing their own profile.
- Add MFA, rate limiting, bot protection, security headers, backups, monitoring and incident response.
- Commission a security review and privacy/data-protection review.
- Have Nigerian counsel and the relevant regulators confirm permissions for each actual activity. Trading, pooled investment management, public offers, lending and deposit-taking can trigger different requirements.
- Use a regulated payment provider and a server-side, idempotent ledger. Never treat a browser redirect as proof of payment.
- Publish clear fees, risks, withdrawal terms, conflicts, custody arrangements and complaints channels.
- Never fund existing customer withdrawals or returns using new customers' deposits.

## Current routes
- `/` landing page and plan information
- `/signup` email registration
- `/login` login
- `/dashboard` authenticated demo dashboard
- `/profile` account profile

## Notes
This is a starter, not a completed audited financial product. Have a qualified developer review it before deployment.
