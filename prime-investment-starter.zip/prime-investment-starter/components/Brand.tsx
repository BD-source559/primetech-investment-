import { Crown } from "lucide-react";
export default function Brand() {
  return <div className="flex items-center gap-3">
    <div className="gold-gradient flex h-11 w-11 items-center justify-center rounded-xl text-[#101B32]"><Crown size={23}/></div>
    <div><div className="font-bold tracking-[.12em] text-white">PRIME INVESTMENT</div><div className="text-[10px] tracking-[.2em] text-gold">FINANCIAL SERVICES</div></div>
  </div>;
}
