import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Prime Investment | Financial Services",
  description: "A transparent investment portfolio and financial activity dashboard."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
