 "use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Brand from "@/components/Brand";
import { createClient } from "@/lib/supabase/client";

export default function Signup() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);
  const router=useRouter();
  async function submit(e:FormEvent){e.preventDefault();setBusy(true);setMessage("");
    try { const supabase=createClient(); const {error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:`${location.origin}/dashboard`}});
      if(error) throw error; setMessage("Registration submitted. Check your email for a verification link."); }
    catch(err:any){setMessage(err.message || "Unable to register. Check your Supabase setup.");}
    finally{setBusy(false);}
  }
  return <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-12"><Brand/><div className="panel mt-8 p-7"><h1 className="text-2xl font-semibold">Create your account</h1><p className="mt-2 text-sm text-muted">Register with your email to access the demo dashboard.</p><form className="mt-6 space-y-4" onSubmit={submit}><label className="block text-sm">Email address<input className="field mt-2" type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label className="block text-sm">Password<input className="field mt-2" type="password" minLength={8} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/></label><button disabled={busy} className="btn gold-gradient w-full text-[#101B32]">{busy?"Creating account…":"Create account"}</button></form>{message&&<p className="mt-4 text-sm text-gold">{message}</p>}<p className="mt-5 text-sm text-muted">Already registered? <Link className="text-gold" href="/login">Log in</Link></p><p className="mt-5 text-xs leading-5 text-slate-500">Demo environment only. No payment details or funds are requested.</p></div></main>;
}
