 "use client";
import { FormEvent,useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Brand from "@/components/Brand";
import { createClient } from "@/lib/supabase/client";

export default function Login(){
 const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [message,setMessage]=useState("");const [busy,setBusy]=useState(false);const router=useRouter();
 async function submit(e:FormEvent){e.preventDefault();setBusy(true);setMessage("");try{const {error}=await createClient().auth.signInWithPassword({email,password});if(error)throw error;router.push("/dashboard");router.refresh();}catch(err:any){setMessage(err.message||"Login failed.");}finally{setBusy(false);}}
 return <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-12"><Brand/><div className="panel mt-8 p-7"><h1 className="text-2xl font-semibold">Welcome back</h1><form className="mt-6 space-y-4" onSubmit={submit}><label className="block text-sm">Email<input className="field mt-2" type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label><label className="block text-sm">Password<input className="field mt-2" type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button disabled={busy} className="btn gold-gradient w-full text-[#101B32]">{busy?"Signing in…":"Log in"}</button></form>{message&&<p className="mt-4 text-sm text-gold">{message}</p>}<p className="mt-5 text-sm text-muted">New to Prime? <Link className="text-gold" href="/signup">Create account</Link></p></div></main>;
}
