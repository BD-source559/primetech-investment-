import Link from "next/link";
import { redirect } from "next/navigation";
import Brand from "@/components/Brand";
import { createClient } from "@/lib/supabase/server";
import { LogOut, Wallet, ChartNoAxesCombined, ReceiptText } from "lucide-react";

export default async function Dashboard(){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
 return <main className="mx-auto min-h-screen max-w-6xl px-5 py-7"><header className="flex flex-wrap items-center justify-between gap-4"><Brand/><form action="/auth/signout" method="post"><button className="flex items-center gap-2 rounded-lg border border-slate-600 px-4 py-2 text-sm"><LogOut size={15}/> Sign out</button></form></header>
 <div className="mt-10"><p className="text-sm text-muted">MEMBER DASHBOARD</p><h1 className="mt-2 text-3xl font-semibold">Welcome to Prime</h1><p className="mt-2 text-sm text-muted">{user.email}</p></div>
 <div className="mt-8 grid gap-4 sm:grid-cols-3">{[["Available balance","₦0.00",Wallet],["Portfolio value","₦0.00",ChartNoAxesCombined],["Transactions","0",ReceiptText]].map(([a,b,I]:any)=><div className="panel p-5" key={a}><I className="text-gold"/><p className="mt-4 text-sm text-muted">{a}</p><p className="mt-1 text-2xl font-semibold">{b}</p></div>)}</div>
 <div className="panel mt-6 p-6"><h2 className="text-xl font-semibold">Account activity</h2><p className="mt-2 text-sm leading-6 text-muted">Your transaction and portfolio records will appear here when the compliant financial ledger is implemented. This starter does not accept deposits, execute trades, issue loans or process withdrawals.</p></div>
 <div className="mt-6 flex flex-wrap gap-3"><Link className="btn gold-gradient text-sm text-[#101B32]" href="/">View plans</Link><Link className="btn border border-slate-600 text-sm" href="/profile">Account profile</Link></div>
 </main>;
}
