import Link from "next/link";
import Brand from "@/components/Brand";
import { ArrowUpRight, ChartNoAxesCombined, ShieldCheck, Wallet, Landmark } from "lucide-react";

const plans = [
  { name: "Basic", amount: "₦7,000", detail: "Entry-level portfolio tier" },
  { name: "Standard", amount: "₦10,000", detail: "Expanded portfolio reporting" },
  { name: "Premium", amount: "₦20,000", detail: "Enhanced portfolio reporting" }
];

export default function Home() {
  return <main className="min-h-screen">
    <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6"><Brand/><div className="flex gap-3"><Link className="rounded-lg border border-slate-600 px-4 py-2 text-sm" href="/login">Log in</Link><Link className="btn gold-gradient text-sm text-[#101B32]" href="/signup">Create account</Link></div></nav>
    <section className="mx-auto grid max-w-6xl items-center gap-12 px-5 pb-20 pt-12 md:grid-cols-2 md:pt-24">
      <div><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#5C4A2B] px-3 py-2 text-xs text-gold"><ShieldCheck size={14}/> Transparency-first financial platform</div>
        <h1 className="max-w-xl text-5xl font-semibold leading-tight md:text-6xl">Build a clearer view of your <span className="text-gold">financial future.</span></h1>
        <p className="mt-6 max-w-lg leading-7 text-muted">Track portfolio activity, understand investment risks and review account transactions in one secure dashboard.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link className="btn gold-gradient inline-flex items-center gap-2 text-[#101B32]" href="/signup">Get started <ArrowUpRight size={17}/></Link><Link className="btn border border-slate-600" href="/login">Member login</Link></div>
        <p className="mt-5 text-xs text-slate-500">Demo starter: no deposits, lending or investment orders are processed.</p>
      </div>
      <div className="panel p-6 shadow-2xl shadow-black/30">
        <div className="flex items-center justify-between"><span className="text-sm text-muted">Portfolio overview</span><span className="rounded-full bg-amber-400/10 px-3 py-1 text-xs text-gold">Preview</span></div>
        <div className="mt-6 text-4xl font-semibold">₦0.00</div><div className="mt-2 text-xs text-muted">Illustrative portfolio value</div>
        <div className="mt-7 grid grid-cols-2 gap-3">
          {[["Available balance","₦0.00",Wallet],["Investment value","₦0.00",ChartNoAxesCombined],["Loan portfolio","₦0.00",Landmark],["Transactions","0",ArrowUpRight]].map(([label,value,Icon]: any)=><div className="rounded-xl bg-[#0D1A2E] p-4" key={label}><Icon size={18} className="text-gold"/><div className="mt-4 text-xs text-muted">{label}</div><div className="mt-1 text-lg font-semibold">{value}</div></div>)}
        </div>
        <div className="mt-5 rounded-xl border border-dashed border-slate-600 p-4 text-sm text-muted">Your verified account activity will appear here after setup.</div>
      </div>
    </section>
    <section className="mx-auto max-w-6xl px-5 pb-20"><div className="mb-8"><p className="text-xs uppercase tracking-[.2em] text-gold">Membership tiers</p><h2 className="mt-2 text-3xl font-semibold">Choose your access level</h2><p className="mt-2 text-sm text-muted">Tier amounts are proposed entry amounts, not promised returns or guaranteed profits.</p></div>
      <div className="grid gap-4 md:grid-cols-3">{plans.map(p=><div className="panel p-6" key={p.name}><div className="text-lg font-semibold">{p.name}</div><div className="mt-4 text-3xl font-semibold text-gold">{p.amount}</div><p className="mt-2 text-sm text-muted">{p.detail}</p><ul className="mt-5 space-y-2 text-sm text-slate-300"><li>• Account activity history</li><li>• Portfolio reporting</li><li>• Risk and fee disclosures</li></ul><Link className="mt-6 block rounded-lg border border-[#8E713D] px-4 py-3 text-center text-sm text-gold" href="/signup">Register to explore</Link></div>)}</div>
    </section>
    <footer className="border-t border-slate-800 px-5 py-8 text-center text-xs leading-6 text-slate-500">Prime Investment prototype · Returns are not guaranteed. Investment values may fall as well as rise. Services must not be offered until the operator has obtained all required authorisations and implemented compliant financial controls.</footer>
  </main>;
}
