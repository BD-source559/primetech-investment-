import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { navy: "#0B1426", panel: "#14233B", gold: "#D6AD55", muted: "#AAB6C9" } } },
  plugins: []
};
export default config;
