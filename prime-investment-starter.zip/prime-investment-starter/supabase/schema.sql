-- Prime Investment starter schema
-- Run in Supabase SQL Editor. This creates profile and audit-friendly transaction
-- structures only. No wallet funding, returns, deposits, withdrawals, or lending
-- settlement functions are included.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  account_status text not null default 'pending' check (account_status in ('pending','active','suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.investment_plans (
  id text primary key,
  name text not null,
  entry_amount_ngn numeric(14,2) not null check (entry_amount_ngn >= 0),
  description text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.portfolio_positions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  asset_category text not null check (asset_category in ('trading','loans','interest_bearing_assets')),
  principal_ngn numeric(14,2) not null default 0 check (principal_ngn >= 0),
  current_value_ngn numeric(14,2) not null default 0 check (current_value_ngn >= 0),
  valuation_date date,
  risk_disclosure_version text,
  created_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  transaction_type text not null check (transaction_type in ('deposit','withdrawal','fee','distribution','adjustment')),
  amount_ngn numeric(14,2) not null check (amount_ngn > 0),
  status text not null default 'pending' check (status in ('pending','approved','rejected','settled')),
  reference text unique,
  description text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id)
);

alter table public.profiles enable row level security;
alter table public.investment_plans enable row level security;
alter table public.portfolio_positions enable row level security;
alter table public.transactions enable row level security;

create policy "Users can read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "Users can update own basic profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Authenticated users can read active plans" on public.investment_plans
  for select to authenticated using (active = true);
create policy "Users can read own portfolio positions" on public.portfolio_positions
  for select to authenticated using (auth.uid() = user_id);
create policy "Users can read own transactions" on public.transactions
  for select to authenticated using (auth.uid() = user_id);

-- Intentionally no client insert/update/delete policies for transactions or positions.
-- Financial ledger writes must be performed only by a separately reviewed,
-- server-side service using a secret key stored outside the browser.
-- Never expose SUPABASE_SERVICE_ROLE_KEY as a NEXT_PUBLIC variable.

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

insert into public.investment_plans (id,name,entry_amount_ngn,description)
values
 ('basic','Basic',7000,'Entry-level portfolio reporting tier. No return is promised.'),
 ('standard','Standard',10000,'Expanded portfolio reporting tier. No return is promised.'),
 ('premium','Premium',20000,'Enhanced portfolio reporting tier. No return is promised.')
on conflict (id) do nothing;
